import Card from "./components/Card"
import data from "./data"

export default function App() {

  const cards = data.slice(0,6).map(item => {
    return (
      <Card item={item} />
    )
  })

  return (
    <div className="container">
      {cards}
    </div>
  )
}


