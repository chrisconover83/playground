export default function Card(props) {
    return (
        <div className="card">
            <img src={props.item.url} className="card--img"/>
            <p className="card--name">{props.item.name}</p>
            <p className="card--breed">{props.item.breed} • {props.item.age} {props.item.age > 1 ? "years" : "year"}</p>
            <p className="card--description">{props.item.description}</p>
        </div>
    )
}